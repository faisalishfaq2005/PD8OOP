﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace task2
{
    internal class Deck
    {
        private List<Card> cards;
        private Random random;

        public Deck()
        {
            cards = new List<Card>();
            random = new Random();

            // Initialize the deck with 52 cards
            for (int suit = 1; suit <= 4; suit++)
            {
                for (int value = 1; value <= 13; value++)
                {
                    cards.Add(new Card(value, suit));
                }
            }
        }

        public void Shuffle()
        {
            // Shuffle the deck
            for (int i = cards.Count - 1; i > 0; i--)
            {
                int j = random.Next(i + 1);
                Card temp = cards[i];
                cards[i] = cards[j];
                cards[j] = temp;
            }
        }

        public int CardsLeft()
        {
            return cards.Count;
        }

        public Card DealCard()
        {
            if (cards.Count == 0)
                return null;

            Card dealtCard = cards[cards.Count - 1];
            cards.RemoveAt(cards.Count - 1);
            return dealtCard;
        }
    }

}
