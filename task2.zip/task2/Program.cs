﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace task2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            PlayMultipleGames(3);
        }
        public static int PlayGame()
        {
            Deck deck = new Deck();
            deck.Shuffle();

            int score = 0;

            Card currentCard = deck.DealCard();
            Console.WriteLine("Current Card: " + currentCard);

            while (true)
            {
                Console.Write("Predict higher (h) or lower (l): ");
                char guess = Console.ReadKey().KeyChar;
                Console.WriteLine();

                Card nextCard = deck.DealCard();

                if (nextCard == null)
                {
                    Console.WriteLine("No more cards left. Game over.");
                    break;
                }

                Console.WriteLine("Next Card: " + nextCard);

                if ((guess == 'h' && nextCard.GetValue() > currentCard.GetValue()) ||
                    (guess == 'l' && nextCard.GetValue() < currentCard.GetValue()))
                {
                    score++;
                    Console.WriteLine("Correct guess!");
                }
                else
                {
                    Console.WriteLine("Incorrect guess. Game over.");
                    break;
                }

                currentCard = nextCard;
            }

            return score;
        }
    }
}
