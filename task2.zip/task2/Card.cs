﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace task2
{
    internal class Card
    {
        private int value;
        private int suit;

        public Card(int theValue, int theSuit)
        {
            value = theValue;
            suit = theSuit;
        }

        public int GetSuit()
        {
            return suit;
        }

        public int GetValue()
        {
            return value;
        }

        public string GetSuitAsString()
        {
            switch (value)
            {
                case 1:
                    return "Ace";
                case 2:
                    return "2";
                case 3:
                    return "3";
                case 4:
                    return "4";
                case 5:
                    return "5";
                case 6:
                    return "6";
                case 7:
                    return "7";
                case 8:
                    return "8";
                case 9:
                    return "9";
                case 10:
                    return "10";
                case 11:
                    return "Jack";
                case 12:
                    return "Queen";
                case 13:
                    return "King";
                default:
                    return "Unknown";
            }
        }

        public string GetValueAsString()
        {
            switch (value)
            {
                case 1:
                    return "Ace";
                case 2:
                    return "2";
                case 3:
                    return "3";
                case 4:
                    return "4";
                case 5:
                    return "5";
                case 6:
                    return "6";
                case 7:
                    return "7";
                case 8:
                    return "8";
                case 9:
                    return "9";
                case 10:
                    return "10";
                case 11:
                    return "Jack";
                case 12:
                    return "Queen";
                case 13:
                    return "King";
                default:
                    return "Unknown";
            }
        }

        public override string ToString()
        {
            return GetValueAsString() + " of " + GetSuitAsString();
        }
    }
}
